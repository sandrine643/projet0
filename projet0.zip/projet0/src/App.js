import logo from './logo.svg';

import Inscription from './pages/inscription'

function App() {
  return (
    <div className="App">
    <Inscription/>

    </div>
  );
}

export default App;
