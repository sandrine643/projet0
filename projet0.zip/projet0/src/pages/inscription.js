
import './inscription.css';
import logo from '../images/etoile.png'
import maison from '../images/maison.png'
import {useState} from 'react'


function Inscription({history}) {
    //à remplacer 
    const [afficherMenuHome,setAfficherMenuHome] = useState(false);
    const testNav = () => {
        console.log("nav")
        history.push(
            {pathname:'/recettes/',
            state:null}
        )
    }
    const AfficherMenuHome = () => {
        console.log("toto")
        if(afficherMenuHome==false)
            setAfficherMenuHome(true)
        else if(afficherMenuHome==true)
            setAfficherMenuHome(false)
    }
// à remplacer   
  return (
    <div className="Inscription">
     Recette
{/* à remplacer */}
     <div className="menu">
            <img className="logo-maison" src={maison} onClick={AfficherMenuHome}/>

            

            <img className="logo-image" src={logo}/>
    </div>
        <div className={afficherMenuHome==false ? "menu-navigation-hidden":"menu-navigation-home"}>
           <div onClick={testNav}>tata 2</div> 
        </div>

{/* à remplacer */}

 {/* Formulaire de connexion et inscription */}


{/* <div class="flex-container">
  <div class="flex-item">Nom</div>
  <div class="flex-item">prenom</div>
  <div class="flex-item">Mail</div>
  <div class="flex-item">Mdp</div>
</div>

<div class="flex-container">
 
  <div class="flex-item2">Login</div>
  <div class="flex-item2">Mdp</div>

  <div class="flex-item2">Connexion</div>
</div> */}


{/* ---------------------------PAGE RECETTE -------------------------------------- */}



{/* <div class="container">
  <div class="item">1</div>
  <div class="item">2</div>
  <div class="item">3</div>
  <div class="item4">4</div>

</div> */}




<div class="container">
<div class="message signup"> 
    { <div class="btn-wrapper">  Pas encore client ? 
    <input type="text" placeholder="Adresse mail"></input>
      <input type="email" placeholder="Prenom"></input>
      <input type="password" placeholder="Mot de passe"></input>
      <input type="password" placeholder="Confirmer le mot de passe"></input>
      <button class="button">Inscription</button>
    </div> }
  </div>
<div class="form form--signup">
    <div class="form--heading">S'inscrire </div>
    <input type="text" placeholder="Adresse mail"></input>
      <input type="password" placeholder="Mot de passe"></input>
      <button class="button">Se connecter</button>
   
  </div>
 

  
  
</div>













</div>


  );
}


export default Inscription;
